import { Component, OnInit ,Input} from '@angular/core';
import { Headers, Http, RequestOptions, Response } from "@angular/http";
import { HttpClient, HttpClientModule } from "@angular/common/http"
import { Observable } from "rxjs";
import 'rxjs/add/operator/map';
import { GlobalService } from '../global.service';
import { UserService } from '../services/user.service';
import { Router } from "@angular/router";
import { PageChangedEvent } from "ngx-bootstrap/pagination";
import { PaginationModule } from 'ngx-bootstrap';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { SweetAlertService } from 'angular-sweetalert-service';
import * as $ from 'jquery';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {
  tabledata: any;
  emptabledata: any = []
  emptablearr: any = []
  addupdateemparr: any = []
  empskilldata:any;
  currentPage: any;
  startVal: any = 0;
  endVal: any;
  tableCount: any;
  loader: number;
  search: any;
  arrKeys: any = [];
  fulltabledata: any;
  getparticularempResults: any;
  emailId: any;
  jobTitle: any;
  mng_username: any;
  mng_userid: any;
  projectName: any;
  projectId: any;
  Experience: any;
  customer: any;
  businesscode: any;
  billstatus: any;
  skillset: any;
  comment: any;
  emp_experience: any;
  bill_details: any;
  emp_userid: any;
  psi_id: any;
  emp_firstname: any;
  emp_lastname: any;
  spent_effort: any;
  emp_project_desc: any;
  emp_note: any;
  uploadEmpDetails_msg: any;
  splitdata: any;
  firstname: any;
  lastname: any;
  useremail: any;
  count: number = 0;
  emp_skills: any;
  skills_in_json: any;
  dynamicDomain: any = [];
  dynamicSkills: any = [];
  dynamicMonths:any=[];
  dynamicLevel:any=[];
  dynamicCertifications:any=[];
  skillSetArr: any = [];
  title:any;
  index:any;
  empskilllength:any;
 domain:any;
    skill:any;
      months:any;
        level:any;
        certificate:any;
        delteindex:any;
  constructor(private http: HttpClient, private router: Router, private alertService: SweetAlertService, public global: GlobalService, public _UserService: UserService) { }

  ngOnInit() {
    this.createNgModels();

    // if (this.global.emptabledata == [] || this.global.emptabledata == undefined) {
    //   this.router.navigate(['dashboard']);
    // }
    this.psi_id = localStorage.getItem("psiid");
    this.useremail = localStorage.getItem("useremail")
    var usernamesplit
    usernamesplit = this.useremail
    this.useremail = usernamesplit.substr(0, usernamesplit.indexOf('@'));
    this.getSingleEmpDetails(this.psi_id);
    this.getEmpSkillsSet()
  }

  getSingleEmpDetails(psi_id) {


    this._UserService.particular_emp_details(psi_id).subscribe(
      getparticularempResults => {
       
        this.getparticularempResults = getparticularempResults;

        this.splitdata = this.getparticularempResults.userName
        this.firstname = this.splitdata.substr(0, this.splitdata.indexOf(' '));
        this.lastname = this.splitdata.substr(this.splitdata.indexOf(' ') + 1);
        if (this.firstname == "") {
          this.firstname = this.lastname
          this.lastname = ""
        }

        this.emailId = this.getparticularempResults.companyEmail;
        this.jobTitle = this.getparticularempResults.jobTitle;
        this.mng_username = this.getparticularempResults.manager.userName;
        this.mng_userid = this.getparticularempResults.manager.userId
        this.projectId = this.getparticularempResults.project.projectId
        this.projectName = this.getparticularempResults.project.projectName
        this.emp_userid = this.getparticularempResults.userId
        this.emp_experience = this.getparticularempResults.emp_experience
        this.skillset = this.getparticularempResults.emp_skill_set
        this.bill_details = this.getparticularempResults.emp_bill_details
        this.emp_firstname = this.getparticularempResults.emp_firstname
        this.emp_lastname = this.getparticularempResults.emp_lastname
        this.emp_project_desc = this.getparticularempResults.emp_project_description
        this.emp_note = this.getparticularempResults.emp_note
        this.spent_effort = this.getparticularempResults.emp_spent_effort


       
      });



  }

  uploadEmpDetails() {
    this.global.userid = this.emp_userid
    this.global.emp_emailId = this.emailId
    this.global.jobtitle = this.jobTitle
    this.global.mng_username = this.mng_username
    this.global.mng_userid = this.mng_userid
    this.global.projectid = this.projectId
    this.global.projectname = this.projectName
    this.global.emp_firstname = this.firstname
    this.global.emp_lastname = this.lastname

    this._UserService.update_emp_details().subscribe(
      getempupdatedetails => {


        this.alertService.success({
          title: 'Employee details updated succesfully !'
        });
        this.router.navigate(['dashboard']);

      });



  }

 


  returntoempdetails() {

    this.router.navigate(['dashboard']);
  }

  addskillfield() {
    this.count += 1;
  
    this.addupdateemparr.push({
      no: this.count,
 
    })
   
   
  }

  delete(index,data,delteindex) {
    this.index =index
    this.skill=data;
    this.delteindex=delteindex
  }

  modaldelclick(){
    this.addupdateemparr.pop(this.index - 1);

    this._UserService.delete_skill(this.psi_id,this.skill).subscribe(
      getempupdatedskills => {
      this.empskilldata=getempupdatedskills;
      
  
      });
    if (this.count > this.index) {
      this.count -= 1;
    }
    else {
      this.count = this.index - 1
    }
    this.dynamicDomain.splice(this.delteindex,1)
    this.dynamicSkills.splice(this.delteindex,1)
    this.dynamicMonths.splice(this.delteindex,1)
    this.dynamicLevel.splice(this.delteindex,1)
    this.dynamicCertifications.splice(this.delteindex,1)
  }
 
  getEmpSkillsSet(){
    this._UserService.get_emp_skillsset(this.psi_id).subscribe(
      getempupdatedskills => {
      this.empskilldata=getempupdatedskills;
      for (let i = 0; i < this.empskilldata.skills.length; i++) {
        this.dynamicDomain[i] = this.empskilldata.skills[i].DomainName;


        this.dynamicSkills[i] = this.empskilldata.skills[i].skillName;
        this.dynamicMonths[i] = this.empskilldata.skills[i].months;
        this.dynamicLevel[i] = this.empskilldata.skills[i].level;
        this.dynamicCertifications[i]=this.empskilldata.skills[i].CertificationStatus
        this.addskillfield();

      }

      });
  }
  submitskill() {

  
    for (let z = 0; z < this.dynamicDomain.length; z++) {

      if (this.dynamicDomain[z] != "") {
        const emp_skills = {
          DomainName: this.dynamicDomain[z],
          skillName: this.dynamicSkills[z],
          months: this.dynamicMonths[z],
          level: this.dynamicLevel[z],
          CertificationStatus: this.dynamicCertifications[z]
        }
        this.skillSetArr.push(emp_skills)
       
      }
   
     
      
    }
   

    // this.skills_in_json = JSON.stringify(emp_skills)
    this._UserService.get_update_skill(this.psi_id,this.skillSetArr,this.splitdata).subscribe(
      getempupdatedskills => {
      this.empskilldata=getempupdatedskills;

      for (let i = 0; i < this.empskilldata.skills.length; i++) {
        this.dynamicDomain[i] = this.empskilldata.skills[i].DomainName;
        this.dynamicSkills[i] = this.empskilldata.skills[i].skillName;
        this.dynamicMonths[i] = this.empskilldata.skills[i].months;
        this.dynamicLevel[i] = this.empskilldata.skills[i].level;
        this.dynamicCertifications[i]=this.empskilldata.skills[i].CertificationStatus
  
      }
      this.alertService.success({
        title: 'Employee Skills updated succesfully !'
      });
      });


  }

  createNgModels() {
    for (let i = 0; i < 15; i++) {
      this.dynamicDomain[i] = "";
      this.dynamicSkills[i] = "";
      this.dynamicMonths[i] = "";
      this.dynamicLevel[i] = "";
      this.dynamicCertifications[i]=""
    }
  }

  getEmployeeDetail(){
    this.router.navigate(['dashboard']);

  }
  addProject(){
    this.router.navigate(['add-emp-project']);
  }

  logout(){
    this.router.navigate(['']);
  }

  mainDashboard(){
    this.router.navigate(['dashboardsection']);
  }
}