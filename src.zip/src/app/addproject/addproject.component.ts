import { Component, OnInit } from '@angular/core';
import { Headers, Http, RequestOptions, Response } from "@angular/http";
import { HttpClient } from "@angular/common/http"
import { Observable } from "rxjs";
import 'rxjs/add/operator/map';
import { GlobalService } from '../global.service';
import { UserService } from '../services/user.service';
import { Router } from "@angular/router";
import { SweetAlertService } from 'angular-sweetalert-service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

@Component({
  selector: 'app-addproject',
  templateUrl: './addproject.component.html',
  styleUrls: ['./addproject.component.css']
})
export class AddprojectComponent implements OnInit {
  useremail: any;
  customer: any;
  Biz_Code: any;
  Status: any;
  Project_Type: any;
  PM: any;
  Group: any;
  Project_ID: any;
  Full_Name: any;
  Short_Name: any;
  Domain: any;
  Start_Date: any;
  End_Date: any;
  Suspended_Date: any;
  Engagging_Date: any;
  Estimation_Effort: any;
  Spent_Effort: any;
  Current_Billable_Headcount: any;
  Technique: any;
  Skill_Set: any;
  Project_Description: any;
  Note: any;
  To_Date: any;
  From_Date: any;
  billed_data: any = [];
  uniqueDatesArr: any = [];
  billObj: any = {};
  
  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();
  constructor(private http: HttpClient, private alertService: SweetAlertService, private router: Router, public global: GlobalService, public _UserService: UserService) {

    this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.bsRangeValue = [this.bsValue, this.maxDate];
  }

  ngOnInit() {
    this.useremail = localStorage.getItem("useremail")
    var usernamesplit
    usernamesplit = this.useremail
    this.useremail = usernamesplit.substr(0, usernamesplit.indexOf('@'));
    this.customer = "Customers"
    this.Biz_Code = "Biz Code"
    this.Status = "Status"
    this.Project_Type = "Project Type"
    this.PM = "Select Project Manager"
    this.Group = "Group"

  }

  getEmployeeDetail() {
    this.router.navigate(['dashboard']);

  }
  addProject() {
    this.router.navigate(['add-emp-project']);
  }
  mainDashboard() {
    this.router.navigate(['dashboardsection']);
  }
  demopage(dateVal:any) {
    localStorage.setItem( "DateVal", dateVal);
    
    this.router.navigate(['demopage']);

  }
  consolidatedata(){
    this.router.navigate(['consolidatedata']);

  }
  takevaluetodropdow(id, value) {
    if (id == "Customers") {
      this.customer = value

    }
    else if (id == "Biz_Code") {
      this.Biz_Code = value
    }
    else if (id == "Status") {
      this.Status = value
    }
    else if (id == "Project_Type") {
      this.Project_Type = value
    }
    else if (id == "PM") {
      this.PM = value
    }
    else if (id == "Group") {
      this.Group = value
    }

  }
  submitProject() {
    this.global.customer = this.customer
    this.global.Biz_Code = this.Biz_Code;
    this.global.Status = this.Status;
    this.global.Project_Type = this.Project_Type;
    this.global.PM = this.PM;
    this.global.Group = this.Group;
    this.global.Project_ID = this.Project_ID;
    this.global.Full_Name = this.Full_Name;
    this.global.Short_Name = this.Short_Name;
    this.global.Domain = this.Domain;
    this.global.Start_Date = this.Start_Date;
    this.global.End_Date = this.End_Date;
    this.global.Suspended_Date = this.Suspended_Date;
    this.global.Engagging_Date = this.Engagging_Date;
    this.global.Estimation_Effort = this.Estimation_Effort;
    this.global.Spent_Efforts = this.Spent_Effort;
    this.global.Current_Billable_Headcount = this.Current_Billable_Headcount;
    this.global.Technique = this.Technique;
    this.global.Skill_Set = this.Skill_Set;
    this.global.Project_Description = this.Project_Description;
    this.global.Note = this.Note;
    this._UserService.add_project_details().subscribe(
      getempupdatedetails => {

        this.customer = "Customers"
        this.Biz_Code = "Biz Code"
        this.Status = "Status"
        this.Project_Type = "Project Type"
        this.PM = "Select Project Manager"
        this.Group = "Group"
        this.Project_ID = "";
        this.Full_Name = "";
        this.Short_Name = "";
        this.Domain = "";
        this.Start_Date = "";
        this.End_Date = "";
        this.Suspended_Date = "";
        this.Engagging_Date = "";
        this.Estimation_Effort = "";
        this.Spent_Effort = "";
        this.Technique = "";
        this.Current_Billable_Headcount = "";
        this.Skill_Set = "";
        this.Project_Description = "";
        this.Note = "";
        this.alertService.success({

          title: 'Employee details updated succesfully !'
        });

      });

  }
  logout() {
    this.router.navigate(['']);
  }
  call() {

    // Mon Dec 10 2018 17:59:51 GMT+0530 (India Standard Time)
    console.log("dates");
    console.log(this.From_Date);
    console.log(this.To_Date);
    let FDate = this.From_Date.toString().split(" ")[2] + '-' + this.From_Date.toString().split(" ")[1].toLowerCase() + '-' + this.From_Date.toString().split(" ")[3];
    let TDate = this.To_Date.toString().split(" ")[2] + '-' + this.To_Date.toString().split(" ")[1].toLowerCase() + '-' + this.To_Date.toString().split(" ")[3];
    console.log(FDate, TDate);
    // let myItem = FDate;
    // let seconddate=TDate;
    
    this._UserService.bill_details(FDate, TDate).subscribe(
      res => {

        console.log(res);
        this.billed_data = res;
        // console.log(typeof (this.billed_data.result));
        let resData = this.billed_data.result;
        for (let i = 0; i < resData.length; i++) {
          // console.log(resData[i]);
          if (this.uniqueDatesArr.indexOf(resData[i].TimeStamp.split(" ")[0]) == -1) {
            this.uniqueDatesArr.push(resData[i].TimeStamp.split(" ")[0])
          }
          // console.log(this.uniqueDatesArr)

        }


        for (let j = 0; j < this.uniqueDatesArr.length; j++) {
          let tempBillArr = [];
          for (let k = 0; k < resData.length; k++) {
            if (this.uniqueDatesArr[j] == resData[k].TimeStamp.split(" ")[0]) {
              if (tempBillArr.indexOf(resData[k].Build_Details) == -1) {
                tempBillArr.push(resData[k].Build_Details);
              }
            }
          }
          this.billObj[this.uniqueDatesArr[j]] = tempBillArr;
          
        }
        console.log(this.billObj)


      });
  }
}
