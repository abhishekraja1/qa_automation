import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { Headers, Http, RequestOptions, Response } from "@angular/http";
import { HttpClient } from "@angular/common/http"
import { Observable } from "rxjs";
import 'rxjs/add/operator/map';
import { GlobalService } from '../global.service';
import { UserService } from '../services/user.service';
import { SweetAlertService } from 'angular-sweetalert-service';

@Component({
  selector: 'app-consolidate',
  templateUrl: './consolidate.component.html',
  styleUrls: ['./consolidate.component.css']
})
export class ConsolidateComponent implements OnInit {

  To_Date: any;
  From_Date: any;
  billed_data: any = [];
  uniqueDatesArr: any = [];
  billObj: any = {};
  responseData: any;
  Total_data_according_to_date: any;
  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();
  test: any;
  tempBillArr: any;
  tableArr: any = [];
  billObjKeys: any = [];
  allUniqueBills: any = [];
  tableObj:any = {};
  allUniqueBillsArr:any=[];

  constructor(private http: HttpClient, private alertService: SweetAlertService, private router: Router, public global: GlobalService, public _UserService: UserService) { }

  ngOnInit() {
  }
  addProject() {
    this.router.navigate(['add-emp-project']);
  }
  mainDashboard() {
    this.router.navigate(['dashboardsection']);
  }
  demopage(dateVal: any) {
    localStorage.setItem("DateVal", dateVal);

    this.router.navigate(['demopage']);

  }
  consolidatedata() {
    this.router.navigate(['consolidatedata']);

  }
  call() {
    this.uniqueDatesArr=[] 
    this.allUniqueBillsArr=[]
    this.billObj={}
    
    let FDate = this.From_Date.toString().split(" ")[2] + '-' + this.From_Date.toString().split(" ")[1].toLowerCase() + '-' + this.From_Date.toString().split(" ")[3];
    let TDate = this.To_Date.toString().split(" ")[2] + '-' + this.To_Date.toString().split(" ")[1].toLowerCase() + '-' + this.To_Date.toString().split(" ")[3];
    this._UserService.bill_details(FDate, TDate).subscribe(
      res => {
        this.billed_data = res;
        let resData = this.billed_data.result;
        for (let i = 0; i < resData.length; i++) {
          if (this.uniqueDatesArr.indexOf(resData[i].TimeStamp.split(" ")[0]) == -1) {
            this.uniqueDatesArr.push(resData[i].TimeStamp.split(" ")[0])
          }
        }



        this.tempBillArr = [];

        for (let j = 0; j < this.uniqueDatesArr.length; j++) {
          let tempBillArr = [];
          let tempBillDetsArr = [];
          for (let k = 0; k < resData.length; k++) {
            if (this.uniqueDatesArr[j] == resData[k].TimeStamp.split(" ")[0]) {

              if (tempBillDetsArr.indexOf(resData[k].Build_Details) == -1) {
                tempBillDetsArr.push(resData[k].Build_Details);
              }
            }

          }
          console.log(this.uniqueDatesArr[j], tempBillDetsArr);

          let billObj2 = {};
          for (let m = 0; m < tempBillDetsArr.length; m++) {
            let billData = [];

            for (let n = 0; n < resData.length; n++) {
              if (tempBillDetsArr[m] == resData[n].Build_Details) {
                console.log(tempBillDetsArr[m], resData[n].Build_Details)
                billData.push(resData[n]);
                if (this.allUniqueBills.indexOf(resData[n].Build_Details) == -1) {
                  this.allUniqueBills.push(resData[n].Build_Details);
                }
              }
            }
            billObj2[tempBillDetsArr[m]] = billData;

          }
          this.billObj[this.uniqueDatesArr[j]] = billObj2;

          console.log("billObj")
          console.log(this.billObj)
          
          // this.billObj
          // let billObjKeys = Object.keys(this.billObj);
          // // for()
          // let final=[]
          // console.log("keysssssssssssssssssss",billObjKeys);
          // for(prop of billObjKeys){
          //     final.push(billObjKeys[prop]);
          //  }
          //    console.log("final")
          //    console.log(final)
        }
        this.initializeTable();
      });


  }

  initializeTable() {
    // this.billObj
    this.billObjKeys = Object.keys(this.billObj);
    // for()
    let final = []
    console.log("keysssssssssssssssssss", this.billObjKeys);
    console.log("all biil dates", this.allUniqueBills)

    for(let i=0;i<this.billObjKeys.length;i++){
      let tempKey = [];
      tempKey = Object.keys(this.billObj[this.billObjKeys[i]])
      console.log(i);
      console.log(tempKey)
      this.allUniqueBillsArr.push(tempKey);
     
    }

    console.log("final")
    console.log(this.allUniqueBillsArr);

  }

}
