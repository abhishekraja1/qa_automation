import { Component, OnInit } from '@angular/core';
import { Headers, Http, RequestOptions, Response } from "@angular/http";
import{HttpClient,HttpHeaders} from "@angular/common/http"
import { Observable } from "rxjs";
import 'rxjs/add/operator/map';
import { GlobalService } from '../global.service';
import { UserService } from '../services/user.service';
import {Router} from "@angular/router";
import { SweetAlertService } from 'angular-sweetalert-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  emailid:any
  password:any;
  loginresponse:any;
  data:any;
  tabledata:any;
  logindata:any;
  checklogindata:any;
  headers: any;
  options: any;
  constructor(private http: HttpClient,private alertService: SweetAlertService,private router: Router,public global:GlobalService,public _UserService: UserService) { }

  ngOnInit() {
    

  }
  private jwt() {
    // create authorization header with jwt token
    this.headers = new Headers({ 'Content-Type': 'application/x-www-form-urlencoded'});
    return new RequestOptions({ headers: this.headers });
  }

 
  loginapi(){
    var username = $("#userid").val()
    var password = $("#password").val()

    this.global.loginusername=username;
    this.global.loginpass=password;

    this.global.loginusername=username;
    this.global.loginpass=password;
    this._UserService.loginapidata().subscribe(
      logindata => {
        this.logindata=logindata
        if (this.logindata.code == 1) {
          this.checkManager();
      }
      else {
         this.alertService.success({

          title: 'invalid credentials'
        });
      }
        
       
  
      });

  }

  checkManager(){

    this._UserService.checkmanager().subscribe(
      checklogindata => {
       this.checklogindata=checklogindata;
        if (this.checklogindata == 'manager') {
          localStorage.setItem("useremail", this.global.loginusername);
          this.router.navigate(['dashboardsection']);
       }
      else {
          localStorage.setItem("useremail", this.global.loginusername);
          this.router.navigate(['dashboardsection']);
          this.alertService.success({

            title: 'Only managers can access this!'
          });
    
         
          

      }
       
  
      });


  }



}
