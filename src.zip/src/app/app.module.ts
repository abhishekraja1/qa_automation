import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { AppComponent } from './app.component';
import { HttpModule, Headers, Http, RequestOptions, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';import * as $ from "jquery";
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GlobalService } from './global.service';
import { UserService } from './services/user.service';
import { AppRoutingModule } from './/app-routing.module';
import { PageChangedEvent } from "ngx-bootstrap/pagination";
import { PaginationModule } from 'ngx-bootstrap';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { SweetAlertService } from 'angular-sweetalert-service';
import { AddprojectComponent } from './addproject/addproject.component';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { DashboardsectionComponent } from './dashboardsection/dashboardsection.component';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { DemoComponent } from './demo/demo.component';
import { ConsolidateComponent } from './consolidate/consolidate.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    
    DashboardComponent,
    UpdateEmployeeComponent,
    AddprojectComponent,
    DashboardsectionComponent,
    DemoComponent,
    ConsolidateComponent,
  ],
  imports: [
    BrowserModule,
    CommonModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    PaginationModule.forRoot(),
    AppRoutingModule,
    BsDatepickerModule.forRoot(),
   
    

    
   
  ],
  providers: [{provide: LocationStrategy, useClass: HashLocationStrategy},GlobalService,UserService,SweetAlertService],
  bootstrap: [AppComponent]
})
export class AppModule { }
