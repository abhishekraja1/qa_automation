import { Injectable } from '@angular/core';

@Injectable()
export class GlobalService {
  BaseURL:any;
  loginURL:any;
  loginemail:any;
  loginpassword:any;
  registeremail:any;
  registerpassword:any;
  registerusername:any;
  emailId:any
  password:any
  empdetailsdata:any=[]
  psiid:any;
  emp_emailId:any;
  jobtitle:any
  mng_username:any
  mng_userid:any
  projectid:any
  projectname:any
  emp_experience:any
  bill_details:any
  skillset:any
  userid:any
  emptabledata:any;
  emp_firstname:any
  emp_lastname:any
  Spent_Effort:any
  emp_project_desc:any
  emp_note:any
  date:any;
 customer:any
 Biz_Code:any
 Status:any
 Project_Type:any
 PM:any
 Group:any
 Project_ID:any
 Full_Name:any
 Short_Name:any
 Domain:any
 Start_Date:any
 End_Date:any
 Suspended_Date:any
 Engagging_Date:any
 Estimation_Effort:any
 Spent_Efforts:any
 Current_Billable_Headcount:any
 Technique:any
 Skill_Set:any
 Project_Description:any
 Note:any
 loginusername:any;
 loginpass:any;
  constructor() { 
this.userid="";
this.emailId="";
this.jobtitle="";
this.mng_username="";
this.mng_userid="";
this.projectid="";
this.projectname="";
this.emp_experience="";
this.bill_details="";
this.skillset="";
this.emp_note="";
this.emp_project_desc="";
this.emp_firstname="";
this.emp_lastname="";
this.Spent_Effort="";

  this.BaseURL = "http://192.168.250.251:5000/";
  this.loginURL="http://epas.terralogic.com/E-PAS/APIs/login_verification.php"



  }
 
}
