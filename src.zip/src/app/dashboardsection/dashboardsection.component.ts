import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";

@Component({
  selector: 'app-dashboardsection',
  templateUrl: './dashboardsection.component.html',
  styleUrls: ['./dashboardsection.component.css']
})
export class DashboardsectionComponent implements OnInit {
  useremail:any;
  constructor(private router: Router) { }

  ngOnInit() {
    this.useremail = localStorage.getItem("useremail")
    var usernamesplit
    usernamesplit = this.useremail
    this.useremail = usernamesplit.substr(0, usernamesplit.indexOf('@'));
  }

 
  Dashboard(){
    this.router.navigate(['add-emp-project']);
  }
  consolidated(){
    this.router.navigate(['consolidatedata']);
  }

  logout(){
    this.router.navigate(['']);
  }
}
