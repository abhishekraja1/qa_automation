import { Component, OnInit } from '@angular/core';
import { Headers, Http, RequestOptions, Response } from "@angular/http";
import{HttpClient} from "@angular/common/http"
import { Observable } from "rxjs";
import 'rxjs/add/operator/map';
import { GlobalService } from '../global.service';
import { UserService } from '../services/user.service';
import {Router} from "@angular/router";
import { PageChangedEvent } from "ngx-bootstrap/pagination";
import { PaginationModule } from 'ngx-bootstrap';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  tabledata:any;
  emptabledata:any=[]
  emptablearr:any=[]
  currentPage:any;
  startVal:any=0;
  endVal:any;
  tableCount:any;
  loader:number;
  search:any;
  arrKeys: any = [];
  fulltabledata:any;
  getparticularempResults:any;
  emailId:any;
  jobTitle:any;
  mng_username:any;
  mng_userid:any;
  projectName:any;
  projectId:any;
  Experience:any;
  customer:any;
  businesscode:any;
  billstatus:any;
  skillset:any;
  comment:any;
  emp_experience:any;
  bill_details:any;
  emp_userid:any;
  useremail:any;
  constructor(private http: HttpClient,private router: Router,public global:GlobalService,public _UserService: UserService) { }

  ngOnInit() {
    this.useremail=localStorage.getItem("useremail")
    var usernamesplit     
    usernamesplit=this.useremail
    this.useremail=usernamesplit.substr(0,usernamesplit.indexOf('@'));
    this.loader=1;
    this.getEmployeeDetail()
    
    
  }


  getEmployeeDetail(){
    if(this.global.emptabledata==[] || this.global.emptabledata==undefined){
        this._UserService.tabledata().subscribe(
        getloginResults => {
          this.tabledata=getloginResults
          this.global.empdetailsdata=this.tabledata.result.data.users
          
          for (let i=0;i<this.global.empdetailsdata.length;i++){
  
            var splitdata
           
            splitdata=this.global.empdetailsdata[i].userName
             var firstname=splitdata.substr(0,splitdata.indexOf(' ')); 
             var lastname=splitdata.substr(splitdata.indexOf(' ')+1); 
             if(firstname==""){
                firstname=lastname
                lastname=""
             }
            this.emptabledata.push({
              userId: this.global.empdetailsdata[i].userId,
              firstname: firstname,
              lastname: lastname,
              jobtitle: this.global.empdetailsdata[i].jobTitle,
              projectname:this.global.empdetailsdata[i].project.projectName
            });
          }
          this.arrKeys = Object.keys(this.emptabledata[0]);
          this.fulltabledata=this.emptabledata
          this.global.emptabledata=this.emptabledata;
          this.emptablearr=this.emptabledata.slice(0, 10)
          this.endVal=10
          this.tableCount=this.emptabledata.length
  
  
        });
  
        this.loader=0;
    }
    else{
     this.emptabledata=this.global.emptabledata
      this.arrKeys = Object.keys(this.emptabledata[0]);
      this.fulltabledata=this.emptabledata
      this.emptablearr=this.emptabledata.slice(0, 10)
      this.endVal=10
      this.tableCount=this.emptabledata.length
    }
    
  

} 
getSingleEmpDetails(psi_id){


  localStorage.setItem("psiid", psi_id);
  this.router.navigate(['update-emp-details']);
 
}
pageChanged(event: PageChangedEvent): void {
  this.currentPage = 0;
  const startItem = (event.page - 1) * event.itemsPerPage;
  const endItem = event.page * event.itemsPerPage;
  this.startVal = startItem + 1;
  this.endVal = endItem;
  if (this.tableCount < endItem) {
    this.endVal = this.tableCount;
  }
  this.emptablearr =this.emptabledata.slice(startItem, this.endVal);
}


  searchEmpdetails(event: any) {
    if (event.target.value) {
      let query = event.target.value.toLowerCase();
      if (event.target.value.length > 0) {
        this.search = [];
        for (let i = 0; i < this.fulltabledata.length; i++) {
          for (let j = 0; j < this.arrKeys.length; j++) {
            let fieldName = this.arrKeys[j];
            let fieldValue = String(this.fulltabledata[i][fieldName]);
            
            fieldValue = fieldValue.toLowerCase();
            if (fieldValue.indexOf(query) > -1) {
              this.search.push(this.fulltabledata[i]);
              break;
            }
          }
        }
      } else {
        this.search=JSON.parse(
          JSON.stringify(this.emptabledata).replace(/\s(?=\w+":)/g, "_")
        );
        
        
      }
    } else {
      this.search=JSON.parse(
        JSON.stringify(this.emptabledata).replace(/\s(?=\w+":)/g, "_")
      );
    }
    this.tableCount = this.search.length;
    let tempSearch = this.search;
    this.emptablearr = this.search.slice(0,10)
    this.startVal = 1;
    if (this.tableCount < 1) {
      this.endVal = this.tableCount;
    } else if (this.tableCount < 10) {
      this.endVal = this.tableCount;
    } else {
      this.endVal = 10;
    }
  }

  addProject(){
    this.router.navigate(['add-emp-project']);

  }

  mainDashboard(){
    this.router.navigate(['dashboardsection']);
  }
  logout(){
    this.router.navigate(['']);
  }
}
