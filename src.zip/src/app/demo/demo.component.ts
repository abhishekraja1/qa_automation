import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})

export class DemoComponent implements OnInit {
  customer: any;
  DateVal: any;
  toDate: any;
  responseData:any;
  // DateVal

  constructor(public _userService : UserService, private router: Router) { }

  ngOnInit() {
    this.DateVal = localStorage.getItem('DateVal');
    console.log(this.DateVal)
    this._userService.get_test_results(this.DateVal).subscribe(
      res => {
        
        this.responseData = res;
        this.responseData = this.responseData.result;
        console.log(this.responseData);
        console.log("anusha")
        console.log(typeof(this.responseData));

      });
  }
  mainDashboard() {
    this.router.navigate(['add-emp-project']);
  }
  consolidatedata(){
    this.router.navigate(['consolidatedata']);
  }
  welcome() {
    this.router.navigate(['dashboardsection']);
  }
  takevaluetodropdow(id, value) {
    if (id == "Customers") {
      this.customer = value

    }


  }
}
