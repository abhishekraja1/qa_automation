import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions, Response } from "@angular/http";
import { HttpClient, HttpHeaders } from "@angular/common/http"
import { Observable } from "rxjs";
import 'rxjs/add/operator/map';
import { GlobalService } from '../global.service';
import { LoginComponent } from '../login/login.component';

@Injectable()
export class UserService {
  skillarr: any = [];
  skills_added: any;
  headers: any;
  options: any;

  constructor(private http: HttpClient, public global: GlobalService) { }

  // logindata(){ 
  //   return (this.http.post('http://epas.terralogic.com/E-PAS/APIs/login_verification.php' ,{
  //     "emailid":this.global.emailId,
  //     "password": this.global.password
  // }));

  // }

  // logincheck(){
  // let url = 'http://127.0.0.1:5000/check_manager/' + this.global.emailId;
  // return this.http.get(url).map((response: Response) => response.json());

  // }
  private jwt() {
    // create authorization header with jwt token
    this.headers = new Headers({ 'Content-Type': 'application/json', });
    return new RequestOptions({ headers: this.headers });
  }

  tabledata() {
    let url = 'http://192.168.250.251:5000/get_intranet_details';
    return this.http.get(url)

  }

  particular_emp_details(psiid) {
    let url = 'http://192.168.250.251:5000/get_particular_emp_details/' + psiid;
    return this.http.get(url)

  }


  update_emp_details() {

    return (this.http.post(this.global.BaseURL + "update_particular_emp_details", {
      "userId": this.global.userid,
      "emp_emailid": this.global.emp_emailId,
      "emp_jobtitle": this.global.jobtitle,
      "emp_mng_username": this.global.mng_username,
      "emp_mng_userid": this.global.mng_userid,
      "emp_projectid": this.global.projectid,
      "emp_projectname": this.global.projectname,
      "emp_firstname": this.global.emp_firstname,
      "emp_lastname": this.global.emp_lastname
    }));

  }

  bill_details(fromDate, toDate) {
    
    console.log(fromDate, toDate)
    return (this.http.post('http://192.168.250.251:5000/Weekly_Data', {
      'from_Date':fromDate,
      'to_Date':toDate
    }));
  }


  get_test_results(DVal){
    // TestCase_Details
    let url = 'http://192.168.250.251:5000/TestCase_Details/' + DVal;
    return this.http.get(url)
  }

  get_update_skill(psiid, emp_skills, userName) {

    return (this.http.post('http://192.168.250.251:5000/particular_skills/' + psiid, {
      "userId": psiid,
      "userName": userName,
      "skills": emp_skills
    }));

  }

  get_emp_skillsset(psiid) {
    let url = 'http://192.168.250.251:5000/get_particular_skills/' + psiid;
    return this.http.get(url)
  }

  delete_skill(psiid, skill) {
    return (this.http.post('http://192.168.250.251:5000/delete_particular_skills/' + psiid, {
      "skillName": skill
    }));
  }

  add_project_details() {
    return (this.http.post(this.global.BaseURL + "project_details", {
      "Customer_Details": this.global.customer,
      "Project_Id": this.global.Project_ID,
      "Project_Fullname": this.global.Full_Name,
      "Project_Shortname": this.global.Short_Name,
      "Biz_Code": this.global.Biz_Code,
      "Project_Status": this.global.Status,
      "Project_Type": this.global.Project_Type,
      "Project_Manager": this.global.PM,
      "Group": this.global.Group,
      "DomainName": this.global.Domain,
      "Start_Date": this.global.Start_Date,
      "End_Date": this.global.End_Date,
      "Suspended_Date": this.global.Suspended_Date,
      "Engaging_Date": this.global.Engagging_Date,
      "Estimation_Effort": this.global.Estimation_Effort,
      "Spent_Effort": this.global.Spent_Efforts,
      "Current_Billable_Headcount": this.global.Current_Billable_Headcount,
      "Technique": this.global.Technique,
      "Skill_Set": this.global.Skill_Set,
      "Project_Description": this.global.Project_Description,
      "Note": this.global.Note

    }));
  }

  loginapidata() {

    var url = 'http://epas.terralogic.com/E-PAS/APIs/login_verification.php'
    var data = {
      "emailid": this.global.loginusername,
      "password": this.global.loginpass
    }
    let httpHeaders = new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    });
    let options = {
      headers: httpHeaders
    };

    return this.http.post(url, JSON.stringify(data), options)


    //      return this.http.post('http://epas.terralogic.com/E-PAS/APIs/login_verification.php', JSON.stringify({
    //        "emailid": this.global.loginusername,
    //        "password": this.global.loginpass
    //      }) , options);  


  }

  checkmanager() {
    let url = 'http://192.168.250.251:5000/check_manager/' + this.global.loginusername;
    return this.http.get(url)
  }
}
