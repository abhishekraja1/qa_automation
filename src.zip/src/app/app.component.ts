import { Component } from '@angular/core';
import { OnInit,ViewChild,ElementRef,HostListener } from '@angular/core';
import { Headers, Http,HttpModule, Request, RequestOptions, Response, XHRBackend } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from "rxjs";
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as $ from "jquery";
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit {
 
  

  constructor(private http: Http,private httpClient: HttpClient) { }

  ngOnInit() {

      
       
  }
  


  
}
