import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule }   from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Routes } from '@angular/router';
import { ActivatedRoute }     from '@angular/router';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { AddprojectComponent } from './addproject/addproject.component';
import { DashboardsectionComponent } from './dashboardsection/dashboardsection.component';
import{ConsolidateComponent} from './consolidate/consolidate.component'
import {DemoComponent} from './demo/demo.component' 
const routes: Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },
  { path: '', component: AddprojectComponent },
  { path: 'dashboard', component:  DashboardComponent},
  { path: 'update-emp-details', component:  UpdateEmployeeComponent},
  { path: 'add-emp-project', component:  AddprojectComponent},
  { path: 'dashboardsection', component:  DashboardsectionComponent},
  { path: 'demopage', component:  DemoComponent},
  { path: 'consolidatedata', component:  ConsolidateComponent},


  
];
@NgModule({
  exports: [ RouterModule ],
	imports: [ RouterModule.forRoot(routes) ],
	declarations: [] // re-export the module declarations
})
export class AppRoutingModule { }
